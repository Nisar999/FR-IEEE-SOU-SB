'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { motion } from 'framer-motion'

export default function Dashboard() {
  // Mock data
  const stats = [
    { label: 'Total Active', value: '24', color: 'from-blue-500 to-blue-600' },
    { label: 'Known Persons', value: '18', color: 'from-green-500 to-green-600' },
    { label: 'Unknown Persons', value: '6', color: 'from-amber-500 to-amber-600' },
    { label: 'Tracked Today', value: '156', color: 'from-purple-500 to-purple-600' },
  ]

  const cameras = [
    { id: 1, name: 'Entrance Hall', status: 'active', fps: 24 },
    { id: 2, name: 'Main Floor', status: 'active', fps: 25 },
    { id: 3, name: 'Conference Room', status: 'active', fps: 24 },
    { id: 4, name: 'Exit Door', status: 'offline', fps: 0 },
    { id: 5, name: 'Parking Lot', status: 'connecting', fps: 12 },
    { id: 6, name: 'Back Entrance', status: 'active', fps: 23 },
  ]

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
          >
            <Card className="border-0 bg-gradient-to-br shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader className={`bg-gradient-to-br ${stat.color} text-white p-4`}>
                <CardTitle className="text-sm font-medium">{stat.label}</CardTitle>
              </CardHeader>
              <CardContent className="pt-4">
                <div className="text-3xl font-bold text-foreground">{stat.value}</div>
                <p className="text-xs text-muted-foreground mt-1">Updated just now</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Video Streams Grid */}
      <div className="space-y-3">
        <div>
          <h3 className="text-lg font-semibold text-foreground">Live Camera Feeds</h3>
          <p className="text-sm text-muted-foreground">Real-time video streams with AI tracking</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {cameras.map((camera, idx) => (
            <motion.div
              key={camera.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: idx * 0.08 }}
            >
              <Card className="overflow-hidden border-0 shadow-lg hover:shadow-xl transition-all duration-300">
                <div className="relative aspect-video bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center group">
                  {/* Mock video stream */}
                  <div className="absolute inset-0 bg-[linear-gradient(45deg,transparent_25%,rgba(68,68,68,.2)_25%,rgba(68,68,68,.2)_50%,transparent_50%,transparent_75%,rgba(68,68,68,.2)_75%,rgba(68,68,68,.2))] bg-[length:40px_40px] animate-pulse"></div>

                  {/* Overlay Info */}
                  <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <div className="text-center">
                      <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur">
                        <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M8 5v14l11-7z" />
                        </svg>
                      </div>
                    </div>
                  </div>

                  {/* Status Badge */}
                  <div className="absolute top-2 right-2 z-10">
                    <Badge className={`
                      ${camera.status === 'active' ? 'bg-green-500 hover:bg-green-600' : ''}
                      ${camera.status === 'offline' ? 'bg-red-500 hover:bg-red-600' : ''}
                      ${camera.status === 'connecting' ? 'bg-amber-500 hover:bg-amber-600' : ''}
                    `}>
                      {camera.status}
                    </Badge>
                  </div>

                  {/* FPS Counter */}
                  <div className="absolute bottom-2 left-2 text-xs text-white/80 bg-black/40 px-2 py-1 rounded backdrop-blur">
                    {camera.fps} FPS
                  </div>
                </div>

                <CardContent className="p-4">
                  <h4 className="font-semibold text-foreground">{camera.name}</h4>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-xs text-muted-foreground">Camera {camera.id}</span>
                    <Badge variant="outline" className="text-xs">Active</Badge>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Recent Activity */}
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="text-lg">Recent Activity</CardTitle>
          <CardDescription>Latest person detections and recognitions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[
              { name: 'John Smith', time: '2 min ago', location: 'Entrance Hall', type: 'known' },
              { name: 'Unknown Person #145', time: '5 min ago', location: 'Main Floor', type: 'unknown' },
              { name: 'Sarah Johnson', time: '8 min ago', location: 'Conference Room', type: 'known' },
              { name: 'Unknown Person #146', time: '12 min ago', location: 'Parking Lot', type: 'unknown' },
            ].map((item, idx) => (
              <div key={idx} className="flex items-center justify-between p-3 bg-background rounded-lg border border-border">
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold ${
                    item.type === 'known' ? 'bg-green-500' : 'bg-amber-500'
                  }`}>
                    {item.name.charAt(0)}
                  </div>
                  <div>
                    <p className="text-sm font-medium text-foreground">{item.name}</p>
                    <p className="text-xs text-muted-foreground">{item.location}</p>
                  </div>
                </div>
                <span className="text-xs text-muted-foreground">{item.time}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
