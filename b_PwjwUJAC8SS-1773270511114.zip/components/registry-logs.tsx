'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'

export default function RegistryLogs() {
  const [unknownPersons, setUnknownPersons] = useState([
    { id: 145, trackId: 'TRK_145', lastSeen: '2 min ago', confidence: 0.87, camera: 'Main Floor' },
    { id: 146, trackId: 'TRK_146', lastSeen: '5 min ago', confidence: 0.92, camera: 'Parking Lot' },
    { id: 144, trackId: 'TRK_144', lastSeen: '15 min ago', confidence: 0.76, camera: 'Entrance Hall' },
  ])

  const knownPersons = [
    { id: 1, name: 'John Smith', lastSeen: '2 min ago', camera: 'Entrance Hall', count: 12 },
    { id: 2, name: 'Sarah Johnson', lastSeen: '8 min ago', camera: 'Conference Room', count: 8 },
    { id: 3, name: 'Mike Davis', lastSeen: '12 min ago', camera: 'Main Floor', count: 15 },
    { id: 4, name: 'Emma Wilson', lastSeen: '25 min ago', camera: 'Exit Door', count: 5 },
  ]

  const [selectedUnknown, setSelectedUnknown] = useState<typeof unknownPersons[0] | null>(null)
  const [promoteSearch, setPromoteSearch] = useState('')

  const handlePromoteToKnown = (id: number) => {
    const name = promoteSearch || `Person_${id}`
    alert(`Promoted unknown person #${id} to known with name: ${name}`)
    setUnknownPersons(unknownPersons.filter(p => p.id !== id))
    setSelectedUnknown(null)
    setPromoteSearch('')
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="known" className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-2 bg-background border border-border rounded-lg p-1">
          <TabsTrigger value="known" className="rounded">Known Persons</TabsTrigger>
          <TabsTrigger value="unknown" className="rounded">Unknown Persons</TabsTrigger>
        </TabsList>

        <TabsContent value="known" className="space-y-4">
          <div className="space-y-2">
            <h3 className="text-lg font-semibold text-foreground">Today's Attendance</h3>
            <p className="text-sm text-muted-foreground">Recognized persons tracked today</p>
          </div>

          <div className="space-y-3">
            {knownPersons.map((person) => (
              <Card key={person.id} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4 flex-1">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center text-white font-bold text-lg">
                        {person.name.charAt(0)}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold text-foreground">{person.name}</h4>
                        <p className="text-xs text-muted-foreground">{person.camera}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge variant="outline" className="bg-green-500/10 text-green-700 border-green-300">
                        Seen {person.count}x
                      </Badge>
                      <p className="text-xs text-muted-foreground mt-2">{person.lastSeen}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="unknown" className="space-y-4">
          <div className="space-y-2">
            <h3 className="text-lg font-semibold text-foreground">Unknown Persons Archive</h3>
            <p className="text-sm text-muted-foreground">Unrecognized individuals detected today</p>
          </div>

          <div className="space-y-3">
            {unknownPersons.map((person) => (
              <Card 
                key={person.id} 
                className={`border-0 shadow-lg hover:shadow-xl transition-all cursor-pointer ${
                  selectedUnknown?.id === person.id ? 'ring-2 ring-primary' : ''
                }`}
                onClick={() => setSelectedUnknown(selectedUnknown?.id === person.id ? null : person)}
              >
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4 flex-1">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center text-white font-bold text-lg">
                        ?
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold text-foreground">Unknown Person #{person.id}</h4>
                        <p className="text-xs text-muted-foreground">{person.camera} • {person.trackId}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge className="bg-amber-500 hover:bg-amber-600">
                        {(person.confidence * 100).toFixed(0)}% Match
                      </Badge>
                      <p className="text-xs text-muted-foreground mt-2">{person.lastSeen}</p>
                    </div>
                  </div>

                  {selectedUnknown?.id === person.id && (
                    <div className="mt-4 pt-4 border-t border-border space-y-3">
                      <div>
                        <label className="text-sm font-medium text-foreground">Assign Name</label>
                        <Input
                          placeholder="Enter person's name..."
                          value={promoteSearch}
                          onChange={(e) => setPromoteSearch(e.target.value)}
                          onKeyPress={(e) => e.key === 'Enter' && handlePromoteToKnown(person.id)}
                          className="mt-2"
                        />
                      </div>
                      <div className="flex gap-2">
                        <Button
                          onClick={() => handlePromoteToKnown(person.id)}
                          className="flex-1 bg-primary hover:bg-primary/90"
                        >
                          Promote to Known
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => setSelectedUnknown(null)}
                          className="flex-1"
                        >
                          Cancel
                        </Button>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>

          {unknownPersons.length === 0 && (
            <Card className="border-0 shadow-lg bg-background/50">
              <CardContent className="p-8 text-center">
                <div className="text-4xl mb-3">✓</div>
                <p className="text-foreground font-medium">All persons have been identified</p>
                <p className="text-sm text-muted-foreground mt-1">No unknown persons in the archive</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
