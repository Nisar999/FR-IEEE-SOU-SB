import { Button } from '@/components/ui/button'

export default function Header({ isDark, setIsDark }: { isDark: boolean; setIsDark: (val: boolean) => void }) {
  return (
    <header className="border-b border-border bg-card/50 backdrop-blur supports-[backdrop-filter]:bg-card/50 sticky top-0 z-40">
      <div className="px-8 py-4 flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">NEत्र Dashboard</h2>
          <p className="text-sm text-muted-foreground mt-1">Real-time person tracking & recognition system</p>
        </div>
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            className="rounded-lg"
            onClick={() => setIsDark(!isDark)}
          >
            {isDark ? '☀️' : '🌙'}
          </Button>
          <div className="flex items-center gap-3 pl-4 border-l border-border">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center">
              <span className="text-white font-bold">A</span>
            </div>
            <div className="text-sm">
              <p className="font-medium text-foreground">Admin</p>
              <p className="text-xs text-muted-foreground">Active now</p>
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}
